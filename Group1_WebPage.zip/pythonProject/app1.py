import streamlit as st
import pandas as pd
import joblib
from datetime import datetime
import base64

# Function to set background image
def set_background(local_image_path):
    with open(local_image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode()
    st.markdown(
        f"""
        <style>
        .stApp {{
            background: url("data:image/png;base64,{encoded_string}") no-repeat center center fixed;
            background-size: cover;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

set_background("hhh.jpg")  # Ensure this image exists

# Load models
preprocessor = joblib.load("preprocessor.joblib")
label_encoder = joblib.load("label_encoder.joblib")
model = joblib.load("xgboost_model.joblib")

# Load taxi data
taxi_data = pd.read_csv("Taxi_IN_OUT_MeanValues.csv")

bins = [0, 6, 12, 18, 24]
labels = ['Night', 'Morning', 'Afternoon', 'Evening']

# Airline list
airlines = ['Alaska Airlines Inc.', 'Southwest Airlines Co.', 'United Air Lines Inc.',
            'Delta Air Lines Inc.', 'Republic Airlines', 'Endeavor Air Inc.', 'Frontier Airlines Inc.',
            'ExpressJet Airlines Inc.', 'JetBlue Airways', 'SkyWest Airlines Inc.', 'Hawaiian Airlines Inc.',
            'Horizon Air', 'Virgin America', 'Allegiant Air', 'Spirit Air Lines',
            'GoJet Airlines, LLC d/b/a United Express',
            'Trans States Airlines', 'Mesa Airlines Inc.', 'Compass Airlines', 'Air Wisconsin Airlines Corp',
            'Commutair Aka Champlain Enterprises, Inc.', 'Peninsula Airways Inc.', 'Cape Air', 'American Airlines Inc.',
            'Envoy Air', 'Comair Inc.', 'Capital Cargo International', 'Empire Airlines Inc.']

origins = taxi_data['Origin'].unique().tolist()
destinations = taxi_data['Dest'].unique().tolist()

# Title
st.markdown("<h1 style='color: white;'>Flight Delay Prediction</h1>", unsafe_allow_html=True)

# Sidebar inputs
st.sidebar.markdown("<h2 style='color: white;'>User Inputs</h2>", unsafe_allow_html=True)

# Dropdowns with empty default option
airline = st.sidebar.selectbox("Airline", ["Select Airline"] + airlines, index=0)
origin = st.sidebar.selectbox("Origin", ["Select Origin"] + origins, index=0)
destination = st.sidebar.selectbox("Destination", ["Select Destination"] + destinations, index=0)

# Date input
date = st.sidebar.date_input("Travel Date", datetime.today())

# Default time values as 00:00
scheduled_dep_time_str = st.sidebar.text_input("Scheduled Departure Time (HH:MM)", "00:00")
scheduled_arr_time_str = st.sidebar.text_input("Scheduled Arrival Time (HH:MM)", "00:00")

# Validate required inputs
if airline == "Select Airline" or origin == "Select Origin" or destination == "Select Destination":
    st.warning("Please select Airline, Origin, and Destination before proceeding.")
else:
    try:
        scheduled_dep_time = datetime.strptime(scheduled_dep_time_str, "%H:%M").time()
        scheduled_arr_time = datetime.strptime(scheduled_arr_time_str, "%H:%M").time()

        if scheduled_arr_time <= scheduled_dep_time:
            st.warning("Arrival time must be greater than departure time! Please check the timings.")
        else:
            # Helper functions
            def parse_time(time_obj):
                total_minutes = time_obj.hour * 60 + time_obj.minute
                hhmm = f"{time_obj.hour:02d}{time_obj.minute:02d}"
                return total_minutes, hhmm

            def calculate_wheels_off_on(schd_dep_time, schd_arr_time, taxi_out=10, taxi_in=20):
                dep_mins, dep_hhmm = parse_time(schd_dep_time)
                arr_mins, arr_hhmm = parse_time(schd_arr_time)
                wheels_off_mins = int(dep_mins + taxi_out)
                wheels_off = f"{(wheels_off_mins // 60) % 24:02d}{wheels_off_mins % 60:02d}"
                flight_duration = int(arr_mins - dep_mins)
                actual_flight_duration = int(flight_duration - (taxi_out + taxi_in))
                wheels_on_mins = int(wheels_off_mins + actual_flight_duration)
                wheels_on = f"{(wheels_on_mins // 60) % 24:02d}{wheels_on_mins % 60:02d}"
                return wheels_off, wheels_on

            def auto_fill_columns(date, scheduled_dep_time, scheduled_arr_time, origin, destination):
                year, month, day_of_month = date.year, date.month, date.day
                day_of_week = date.weekday() + 1
                is_weekend = 1 if day_of_week in [6, 7] else 0
                schd_dep_hour = scheduled_dep_time.hour
                schd_dep_time_of_day = pd.cut([schd_dep_hour], bins=bins, labels=labels, right=False)[0]
                taxi_info = taxi_data[(taxi_data['Origin'] == origin) & (taxi_data['Dest'] == destination)]
                taxi_in = taxi_info.iloc[0]['TaxiIn'] if not taxi_info.empty else 10
                taxi_out = taxi_info.iloc[0]['TaxiOut'] if not taxi_info.empty else 15
                wheels_off, wheels_on = calculate_wheels_off_on(scheduled_dep_time, scheduled_arr_time, taxi_out, taxi_in)
                return pd.DataFrame({
                    "Airline": [airline], "Origin": [origin], "Dest": [destination], "SchdDepHour": [schd_dep_hour],
                    "SchdDepTimeOfDay": [schd_dep_time_of_day], "Year": [year], "Quarter": [(month - 1) // 3 + 1],
                    "Month": [month], "DayofMonth": [day_of_month], "DayOfWeek": [day_of_week], "IsWeekend": [is_weekend],
                    "TaxiOut": [taxi_out], "WheelsOff": [wheels_off], "WheelsOn": [wheels_on], "TaxiIn": [taxi_in],
                    "SchdArrTime": [scheduled_arr_time.hour],
                })

            # Prepare input data
            input_df = auto_fill_columns(date, scheduled_dep_time, scheduled_arr_time, origin, destination)

            # Prediction button
            if st.button("Predict"):
                input_processed = preprocessor.transform(input_df)
                prediction_proba = model.predict_proba(input_processed)
                predicted_class_index = prediction_proba.argmax()
                prediction_label = label_encoder.inverse_transform([predicted_class_index])[0]
                probability = prediction_proba[0][predicted_class_index] * 100

                # Display results
                st.markdown("<h3 style='color: white;'>Prediction Probabilities:</h3>", unsafe_allow_html=True)
                for i, prob in enumerate(prediction_proba[0]):
                    class_label = label_encoder.inverse_transform([i])[0]
                    st.markdown(f"<p style='color: white;'>{class_label}: {prob * 100:.2f}%</p>", unsafe_allow_html=True)

                st.markdown(f"<h2 style='color: white;'>Predicted Delay Probability: {prediction_label}</h2>", unsafe_allow_html=True)
                st.markdown(f"<h3 style='color: white;'>Confidence Level: {probability:.2f}%</h3>", unsafe_allow_html=True)

    except ValueError:
        st.error("Invalid time format. Please enter the time in HH:MM format.")
